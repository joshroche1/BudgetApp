package net.jar.quarkus.budgetapp;

import java.util.List;
import java.util.ArrayList;

import jakarta.enterprise.context.ApplicationScoped;

import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;

import io.smallrye.mutiny.Uni;

import org.jboss.logging.Logger;

@Path("budget")
@ApplicationScoped
public class BudgetResource {

  private static final Logger LOGGER = Logger.getLogger(BudgetResource.class.getName());

  @GET
  @Produces(MediaType.APPLICATION_JSON)
  public Uni<List<BudgetEntity>> getAll() {
    return BudgetEntity.listAll();
  }

}